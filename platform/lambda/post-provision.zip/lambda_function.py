import json
import boto3

sns = boto3.client('sns')
iam_identity_center = boto3.client('sso-admin')
dynamodb = boto3.resource('dynamodb')
environments_table = dynamodb.Table('cloudflow-environments')

SNS_TOPIC_ARN = 'arn:aws:sns:us-east-1:232245183374:cloudflow-notifications'

def lambda_handler(event, context):
    environment_id = event.get('environmentId')
    
    try:
        response = environments_table.get_item(Key={'environmentId': environment_id})
        env = response.get('Item')
        
        if not env:
            return {'statusCode': 404, 'success': False, 'reason': 'Environment not found'}
        
        team_name = env.get('teamName')
        environment_type = env.get('environmentType')
        app_name = env.get('appName')
        requested_by = env.get('requestedBy')
        vpc_id = env.get('vpcId', 'N/A')
        
        # Send notification email
        message = f"""Your CloudFlow environment is ready!

Team: {team_name}
Environment: {environment_type}
Application: {app_name}
VPC ID: {vpc_id}

Access: Log in to AWS console and refresh to see your new account.
"""
        
        try:
            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject=f'CloudFlow: {team_name} {environment_type} environment ready',
                Message=message
            )
        except Exception as e:
            print(f"Failed to send SNS notification: {str(e)}")
        
        return {
            'statusCode': 200,
            'success': True,
            'message': 'Post-provision tasks completed'
        }
        
    except Exception as e:
        return {'statusCode': 500, 'success': False, 'reason': str(e)}
