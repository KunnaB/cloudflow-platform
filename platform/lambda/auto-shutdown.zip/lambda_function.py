import json
import boto3
from datetime import datetime

ec2 = boto3.client('ec2')
rds = boto3.client('rds')
dynamodb = boto3.resource('dynamodb')
environments_table = dynamodb.Table('cloudflow-environments')

def lambda_handler(event, context):
    """
    Stop all dev environment resources to save cost
    Triggered by EventBridge at 6pm weekdays
    """
    
    stopped_instances = []
    stopped_databases = []
    
    try:
        # Get all dev environments
        response = environments_table.scan(
            FilterExpression='environmentType = :env AND #status = :ready',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={':env': 'dev', ':ready': 'ready'}
        )
        
        for env in response.get('Items', []):
            environment_id = env.get('environmentId')
            team_name = env.get('teamName')
            
            # Check for override tag
            # In real implementation, would check AWS tags for AutoShutdown=false
            
            # Stop EC2 instances (dev uses EC2)
            # In real implementation:
            # instances = ec2.describe_instances(Filters=[{'Name': 'tag:EnvironmentId', 'Values': [environment_id]}])
            # ec2.stop_instances(InstanceIds=[...])
            
            print(f"Would stop EC2 instances for {team_name} dev environment")
            stopped_instances.append(environment_id)
            
            # Stop RDS instances
            # rds.stop_db_instance(DBInstanceIdentifier=f"{team_name}-dev-db")
            print(f"Would stop RDS for {team_name} dev environment")
            stopped_databases.append(environment_id)
        
        return {
            'statusCode': 200,
            'success': True,
            'message': f'Stopped {len(stopped_instances)} EC2 instances and {len(stopped_databases)} RDS instances',
            'stoppedInstances': stopped_instances,
            'stoppedDatabases': stopped_databases
        }
        
    except Exception as e:
        print(f"Error during auto-shutdown: {str(e)}")
        return {'statusCode': 500, 'success': False, 'reason': str(e)}
